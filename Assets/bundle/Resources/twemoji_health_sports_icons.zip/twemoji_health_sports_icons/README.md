# Twemoji Health Sports Icon Pack

用于 `eldercare-vr` 的「健康运动选择页」资源整理包。

## CoreSports

| 文件 | Twemoji 原始文件 | Unicode / Emoji | UI 用途 |
|---|---|---|---|
| `table_tennis.svg` | `assets/svg/1f3d3.svg` | U+1F3D3 🏓 | 乒乓球卡片 |
| `bow_and_arrow.svg` | `assets/svg/1f3f9.svg` | U+1F3F9 🏹 | 射箭卡片 |
| `direct_hit.svg` | `assets/svg/1f3af.svg` | U+1F3AF 🎯 | 飞镖卡片 |

## UiSupport

| 文件 | Twemoji 原始文件 | Unicode / Emoji | 建议用途 |
|---|---|---|---|
| `stopwatch.svg` | `assets/svg/23f1.svg` | U+23F1 ⏱ | 运动时长 |
| `sparkles.svg` | `assets/svg/2728.svg` | U+2728 ✨ | 今日推荐 |
| `back_arrow.svg` | `assets/svg/2b05.svg` | U+2B05 ⬅ | 返回 |
| `home.svg` | `assets/svg/1f3e0.svg` | U+1F3E0 🏠 | 返回首页 |
| `gear.svg` | `assets/svg/2699.svg` | U+2699 ⚙ | 设置 |
| `heart.svg` | `assets/svg/2764.svg` | U+2764 ❤ | 健康/标题 |

## eldercare-vr 使用建议

为与现有康复运动选择页保持一致：

1. 三个核心运动图标可使用本包 SVG。
2. `gear / heart / home` 等通用 UI 图标，若项目现有
   `Assets/Resources/HtmlSvgIcons` 已有对应资源，优先复用项目现有版本。
3. 不要在最终 Unity UI 中使用系统 Emoji 字符替代图标。
4. SVG 原图保持 Twemoji 原始配色；如为了康复页风格进行重新着色，请在 attribution 中注明修改。

## 推荐放置位置

可以复制到：

`Assets/Resources/HealthSportsIcons/`

或整合进项目现有：

`Assets/Resources/HtmlSvgIcons/`

如果沿用当前 `HtmlSvgIcons` 加载体系，建议避免与现有同名 PNG 资源发生不明确的 Resources.Load 匹配。
