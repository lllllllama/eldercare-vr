# Tabler ElderCare VR UI Icon Pack

为 `eldercare-vr` 整理的 15 个 Tabler Icons Outline 通用 UI 图标。

## 目录
- `OriginalStyle/`：保持 Tabler 的 `currentColor` 线条风格；为了打包简洁，移除了源文件顶部的元数据注释，SVG 几何与视觉参数保持一致。
- `UnityWarm/`：在同一几何基础上，将 `currentColor` 固定为 `#3E2E1F`，用于匹配现有康复选择页的深棕文字/描边。

## 用途
- Navigation：返回、主页
- Controls：设置、时长、音量、播放、暂停
- Status：完成、帮助、关闭、信息、无障碍
- ProfileData：排行榜/成就、用户、训练记录

## 项目建议
主运动卡片仍建议使用 Twemoji（乒乓球 / 射箭 / 飞镖）。
通用按钮和状态图标统一使用本 Tabler 包，这样不会混杂多套线性 UI 风格。

推荐放置：
`Assets/Resources/UiIcons/Tabler/`

## 许可
Source: https://github.com/tabler/tabler-icons
License: MIT
保留本目录的 `LICENSE-TABLER`。
